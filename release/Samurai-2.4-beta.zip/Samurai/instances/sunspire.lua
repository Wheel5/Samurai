SAMURAI = SAMURAI or { }
local sam = SAMURAI

local ss = sam.Instance:New(1121, nil, nil)

ss:AddAlert(sam.TimerNotification:New("TransApoc", "00f2de", "Interrupt", EVENT_COMBAT_EVENT, ACTION_RESULT_BEGIN, {121436}, false))
ss:AddAlert(sam.TimerNotification:New("ssNegate", "c60dff", "Negate", EVENT_COMBAT_EVENT, ACTION_RESULT_BEGIN, {121411}, true))
ss:AddAlert(sam.TimerNotification:New("ssGale", "ffcb0d", "Gale", EVENT_COMBAT_EVENT, ACTION_RESULT_BEGIN, {121422}, true))
ss:AddAlert(sam.TimerNotification:New("ssIce", "0dffe7", "Ice", EVENT_COMBAT_EVENT, ACTION_RESULT_BEGIN, {121074}, true))

--table.insert(sam.instances, ss)
